package com.example.tripcue.frame.uicomponents.signup

import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.example.tripcue.frame.model.Routes
import com.google.firebase.firestore.FirebaseFirestore

@Composable
fun FillProfileScreen(navController: NavController) {
    val context = LocalContext.current
    val uid = "some_user_id" // 실제 로그인된 유저 ID로 대체 필요
    val userData = hashMapOf("name" to "사용자 이름", "email" to "example@email.com")
    var isLoading by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(text = "저장하고 시작하기")

        // 예시: 저장 버튼 클릭 시 실행되는 로직
        FirebaseFirestore.getInstance()
            .collection("users")
            .document(uid)
            .set(userData)
            .addOnSuccessListener {
                isLoading = false
                Toast.makeText(context, "프로필 저장 완료!", Toast.LENGTH_SHORT).show()
                navController.navigate(Routes.Login.route)
            }
            .addOnFailureListener {
                isLoading = false
                Toast.makeText(context, "유저 정보 저장 실패: ${it.message}", Toast.LENGTH_SHORT).show()
            }
    }
}