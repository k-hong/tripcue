package com.example.tripcue.frame.model.factory

object AddressListFactory {
    fun makeAddressList() = mutableListOf("", "군자동", "구의제3동", "휘경동")
}