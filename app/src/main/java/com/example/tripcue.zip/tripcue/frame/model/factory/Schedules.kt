package com.example.tripcue.frame.model.factory

import androidx.compose.runtime.mutableStateListOf
import com.example.tripcue.frame.model.ScheduleTitle

object Schedules { val schedules = mutableStateListOf<ScheduleTitle>() }
