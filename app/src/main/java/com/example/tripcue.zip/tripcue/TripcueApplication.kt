package com.example.tripcue

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class TripcueApplication : Application()
