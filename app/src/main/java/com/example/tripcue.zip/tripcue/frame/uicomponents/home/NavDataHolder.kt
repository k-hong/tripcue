package com.example.tripcue.frame.uicomponents.home

// 화면 전환 시 데이터를 임시로 보관하는 객체
object NavDataHolder {
    var place: PlaceInfo? = null
}